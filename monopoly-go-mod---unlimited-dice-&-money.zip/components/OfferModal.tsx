
import React, { useState, useEffect, useCallback } from 'react';
import { Offer, Lead, Platform } from '../types';
import { fetchOffers, checkLeadCompletion } from '../services/offerService';

interface OfferModalProps {
  isOpen: boolean;
  onClose: () => void;
  platform: Platform | null;
  onSuccess: () => void;
}

const OfferModal: React.FC<OfferModalProps> = ({ isOpen, onClose, platform, onSuccess }) => {
  const [offers, setOffers] = useState<Offer[]>([]);
  const [loading, setLoading] = useState(true);
  const [checking, setChecking] = useState(false);
  const [status, setStatus] = useState('Waiting for offer completion...');

  useEffect(() => {
    if (isOpen) {
      setLoading(true);
      fetchOffers().then(data => {
        setOffers(data);
        setLoading(false);
      });
    }
  }, [isOpen]);

  const verifyLeads = useCallback(async () => {
    if (!isOpen) return;
    setChecking(true);
    const leads = await checkLeadCompletion(false); // Change to true for testing
    if (leads && leads.length > 0) {
      onSuccess();
    } else {
      setChecking(false);
    }
  }, [isOpen, onSuccess]);

  useEffect(() => {
    let interval: any;
    if (isOpen) {
      interval = setInterval(() => {
        verifyLeads();
      }, 10000); // Check every 10 seconds for faster feedback
    }
    return () => clearInterval(interval);
  }, [isOpen, verifyLeads]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-white text-gray-900 w-full max-w-md rounded-2xl overflow-hidden shadow-2xl animate-in fade-in zoom-in duration-300">
        <div className="bg-monopoly-red p-6 text-white text-center relative">
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 text-white/80 hover:text-white transition-colors"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
          <h2 className="text-2xl font-monopoly tracking-wider">Human Verification</h2>
          <p className="text-sm opacity-90 mt-1">Complete one offer below to start your {platform === 'ios' ? 'iOS' : 'Android'} download.</p>
        </div>

        <div className="p-6">
          {loading ? (
            <div className="flex flex-col items-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-monopoly-red"></div>
              <p className="mt-4 text-gray-500 font-medium">Loading available offers...</p>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="bg-blue-50 border-l-4 border-blue-500 p-4 mb-4">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <svg className="h-5 w-5 text-blue-400" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <div className="ml-3">
                    <p className="text-xs text-blue-700 font-medium">
                      Verification will automatically complete after you finish an offer. Keep this window open.
                    </p>
                  </div>
                </div>
              </div>

              {offers.length > 0 ? (
                offers.map((offer, idx) => (
                  <a
                    key={idx}
                    href={offer.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-between p-4 border border-gray-200 rounded-xl hover:border-monopoly-red hover:bg-red-50 transition-all group"
                  >
                    <div className="flex flex-col">
                      <span className="font-bold text-gray-800 group-hover:text-monopoly-red transition-colors">{offer.anchor}</span>
                      <span className="text-xs text-gray-500">{offer.conversion || 'Fast Verification'}</span>
                    </div>
                    <div className="bg-monopoly-green text-white px-3 py-1 rounded-full text-xs font-bold">
                      FREE
                    </div>
                  </a>
                ))
              ) : (
                <p className="text-center text-gray-500 py-8">No offers available for your region at this moment. Please try again later.</p>
              )}

              <div className="mt-6 flex items-center justify-center space-x-2 text-sm text-gray-500">
                <div className={`w-2 h-2 rounded-full ${checking ? 'bg-monopoly-green animate-pulse' : 'bg-gray-300'}`}></div>
                <span>{checking ? 'Checking for completion...' : status}</span>
              </div>
            </div>
          )}
        </div>
        
        <div className="bg-gray-50 p-4 text-center border-t border-gray-100">
          <p className="text-[10px] text-gray-400 uppercase tracking-widest font-semibold">Verified by Monopoly Go System</p>
        </div>
      </div>
    </div>
  );
};

export default OfferModal;
