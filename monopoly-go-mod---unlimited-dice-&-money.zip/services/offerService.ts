
import { Offer, Lead } from '../types';

const USER_ID = '163295';
const API_KEY = '067612d5c76e53aa8bbe315d6d47d1d7';

/**
 * Modern JSONP implementation since standard fetch won't work with these legacy callback endpoints
 */
const jsonp = <T,>(url: string): Promise<T> => {
  return new Promise((resolve, reject) => {
    const callbackName = `jsonp_callback_${Math.round(100000 * Math.random())}`;
    const script = document.createElement('script');
    
    (window as any)[callbackName] = (data: T) => {
      delete (window as any)[callbackName];
      document.body.removeChild(script);
      resolve(data);
    };

    script.src = `${url}${url.includes('?') ? '&' : '?'}callback=${callbackName}`;
    script.onerror = () => {
      delete (window as any)[callbackName];
      document.body.removeChild(script);
      reject(new Error('JSONP request failed'));
    };
    document.body.appendChild(script);
  });
};

export const fetchOffers = async (): Promise<Offer[]> => {
  const url = `https://d1y3y09sav47f5.cloudfront.net/public/offers/feed.php?user_id=${USER_ID}&api_key=${API_KEY}&s1=&s2=`;
  try {
    const data = await jsonp<Offer[]>(url);
    return data.slice(0, 3); // Updated from 5 to 3 as requested
  } catch (error) {
    console.error('Error fetching offers:', error);
    return [];
  }
};

export const checkLeadCompletion = async (isTesting: boolean = false): Promise<Lead[]> => {
  const testParam = isTesting ? '1' : '0';
  const realUrl = `https://d1y3y09sav47f5.cloudfront.net/public/external/check2.php?testing=${testParam}`;
  
  try {
    const data = await jsonp<Lead[]>(realUrl);
    return Array.isArray(data) ? data : [];
  } catch (error) {
    console.error('Error checking leads:', error);
    return [];
  }
};
