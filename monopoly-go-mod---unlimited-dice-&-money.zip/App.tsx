
import React, { useState } from 'react';
import OfferModal from './components/OfferModal';
import { Platform } from './types';

const App: React.FC = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedPlatform, setSelectedPlatform] = useState<Platform | null>(null);
  const [completed, setCompleted] = useState(false);

  const handleDownloadClick = (platform: Platform) => {
    setSelectedPlatform(platform);
    setIsModalOpen(true);
  };

  const handleSuccess = () => {
    setCompleted(true);
    setIsModalOpen(false);
    // In a real app, you'd trigger the file download here
    alert(`Verification Successful! Your ${selectedPlatform?.toUpperCase()} Mod APK download is starting now.`);
    window.location.href = "https://example.com/download-link"; // Placeholder
  };

  return (
    <div className="min-h-screen bg-gray-950 selection:bg-monopoly-red selection:text-white overflow-x-hidden">
      {/* Background Decor */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none opacity-20">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-monopoly-red rounded-full blur-[120px]"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-monopoly-green rounded-full blur-[120px]"></div>
      </div>

      <header className="relative z-10 container mx-auto px-4 py-6 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-monopoly-red rounded-lg flex items-center justify-center font-monopoly text-2xl border-2 border-white">M</div>
          <span className="font-monopoly text-2xl tracking-tighter">MONOPOLY GO <span className="text-monopoly-red">MODS</span></span>
        </div>
        <nav className="hidden md:flex items-center gap-8 text-sm font-semibold text-gray-400">
          <a href="#" className="hover:text-white transition-colors">FEATURES</a>
          <a href="#" className="hover:text-white transition-colors">HOW TO INSTALL</a>
          <a href="#" className="hover:text-white transition-colors">FAQ</a>
          <button 
            onClick={() => handleDownloadClick('android')}
            className="bg-white text-black px-6 py-2 rounded-full hover:bg-monopoly-red hover:text-white transition-all transform active:scale-95"
          >
            GET MOD
          </button>
        </nav>
      </header>

      <main className="relative z-10 container mx-auto px-4 pt-12 pb-24">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          {/* Left Content */}
          <div className="flex-1 text-center lg:text-left space-y-8 animate-in slide-in-from-left duration-700">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs font-bold text-monopoly-red tracking-widest uppercase">
              <span className="flex h-2 w-2 rounded-full bg-monopoly-red animate-ping"></span>
              Working March 2025
            </div>
            
            <h1 className="text-5xl md:text-7xl font-monopoly leading-tight tracking-tight">
              UNLIMITED <span className="text-monopoly-red">DICE ROLLS</span> <br />
              & MONEY FOR FREE
            </h1>
            
            <p className="text-lg text-gray-400 max-w-xl mx-auto lg:mx-0 leading-relaxed">
              Dominate the board with the latest Monopoly Go Mod APK. Get access to unlimited dice, instant money, and premium features without spending a dime. Safe, secure, and undetectable.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4">
              <button 
                onClick={() => handleDownloadClick('android')}
                className="group relative w-full sm:w-auto px-10 py-5 bg-monopoly-green rounded-2xl flex items-center justify-center gap-4 hover:scale-105 active:scale-95 transition-all shadow-[0_0_30px_rgba(0,166,81,0.3)] animate-pulse-slow"
              >
                <img src="https://www.svgrepo.com/show/303152/android-logo.svg" className="w-6 h-6 invert" alt="Android" />
                <div className="text-left">
                  <div className="text-[10px] uppercase font-bold opacity-80 leading-none">Download for</div>
                  <div className="text-xl font-bold leading-tight">Android APK</div>
                </div>
              </button>

              <button 
                onClick={() => handleDownloadClick('ios')}
                className="group relative w-full sm:w-auto px-10 py-5 bg-white text-black rounded-2xl flex items-center justify-center gap-4 hover:scale-105 active:scale-95 transition-all shadow-[0_0_30px_rgba(255,255,255,0.1)]"
              >
                <img src="https://www.svgrepo.com/show/303108/apple-ios-logo.svg" className="w-6 h-6" alt="iOS" />
                <div className="text-left">
                  <div className="text-[10px] uppercase font-bold opacity-70 leading-none">Download for</div>
                  <div className="text-xl font-bold leading-tight">iOS Device</div>
                </div>
              </button>
            </div>

            <div className="flex items-center justify-center lg:justify-start gap-6 pt-4 text-xs font-bold text-gray-500">
              <div className="flex items-center gap-2">
                <svg className="w-5 h-5 text-monopoly-green" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path></svg>
                NO ROOT REQUIRED
              </div>
              <div className="flex items-center gap-2">
                <svg className="w-5 h-5 text-monopoly-green" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path></svg>
                ANTI-BAN PROTECTION
              </div>
            </div>
          </div>

          {/* Right Image */}
          <div className="flex-1 relative animate-in zoom-in duration-1000">
            <div className="relative z-10 bg-gradient-to-br from-white/10 to-transparent p-4 rounded-[40px] backdrop-blur-md border border-white/20 shadow-2xl">
              <img 
                src="https://monopolygomods.com/wp-content/uploads/2025/03/monopoly-go-mod-apk-monopolygomods.png" 
                alt="Monopoly Go Mod APK Preview"
                className="w-full max-w-lg mx-auto rounded-[30px]"
              />
            </div>
            {/* Floating Elements */}
            <div className="absolute -top-6 -right-6 w-24 h-24 bg-monopoly-red rounded-2xl flex items-center justify-center font-monopoly text-4xl shadow-2xl animate-bounce">
              MOD
            </div>
            <div className="absolute -bottom-10 -left-10 bg-gray-900 border border-white/10 p-6 rounded-3xl shadow-2xl backdrop-blur-xl hidden md:block">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-monopoly-green rounded-full flex items-center justify-center text-2xl">💰</div>
                <div>
                  <div className="text-xs text-gray-400 font-bold uppercase">Current Wallet</div>
                  <div className="text-xl font-bold text-monopoly-green">999,999,999</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Features Section */}
        <section className="mt-32 grid md:grid-cols-3 gap-8">
          {[
            {
              title: "Unlimited Dice",
              desc: "Never run out of dice rolls again. Move as much as you want and win every tournament.",
              icon: "🎲"
            },
            {
              title: "Infinite Money",
              desc: "Build all your boards instantly with zero cost. Become the wealthiest tycoon on the server.",
              icon: "💎"
            },
            {
              title: "Safe to Use",
              desc: "Our mod uses proxy integration and advanced encryption to keep your account 100% safe.",
              icon: "🛡️"
            }
          ].map((feature, i) => (
            <div key={i} className="bg-white/5 border border-white/10 p-10 rounded-[32px] hover:bg-white/10 transition-colors group">
              <div className="text-5xl mb-6 group-hover:scale-110 transition-transform inline-block">{feature.icon}</div>
              <h3 className="text-2xl font-monopoly mb-4 tracking-wide">{feature.title}</h3>
              <p className="text-gray-400 leading-relaxed">{feature.desc}</p>
            </div>
          ))}
        </section>

        {/* Stats Section */}
        <section className="mt-32 text-center bg-monopoly-red rounded-[40px] py-16 px-8 relative overflow-hidden">
          <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]"></div>
          <div className="relative z-10 grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            <div>
              <div className="text-5xl font-monopoly mb-2">1.2M+</div>
              <div className="text-xs font-bold opacity-80 uppercase tracking-widest">Downloads</div>
            </div>
            <div>
              <div className="text-5xl font-monopoly mb-2">4.9/5</div>
              <div className="text-xs font-bold opacity-80 uppercase tracking-widest">User Rating</div>
            </div>
            <div>
              <div className="text-5xl font-monopoly mb-2">100%</div>
              <div className="text-xs font-bold opacity-80 uppercase tracking-widest">Uptime</div>
            </div>
            <div>
              <div className="text-5xl font-monopoly mb-2">24/7</div>
              <div className="text-xs font-bold opacity-80 uppercase tracking-widest">Live Support</div>
            </div>
          </div>
        </section>
      </main>

      <footer className="relative z-10 border-t border-white/5 pt-12 pb-24 text-center">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-center gap-2 mb-8">
            <div className="w-8 h-8 bg-gray-800 rounded flex items-center justify-center font-monopoly text-lg border border-white/10 text-white/50">M</div>
            <span className="font-monopoly text-xl tracking-tighter text-white/50">MONOPOLY GO MODS</span>
          </div>
          <p className="text-gray-600 text-sm max-w-lg mx-auto">
            Monopoly Go Mod is a third-party modification and is not affiliated with Hasbro, Scopely, or the official Monopoly Go game. Use at your own risk.
          </p>
        </div>
      </footer>

      {/* Verification Modal */}
      <OfferModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        platform={selectedPlatform}
        onSuccess={handleSuccess}
      />
    </div>
  );
};

export default App;
