
export interface Offer {
  url: string;
  anchor: string;
  conversion: string;
  offer_id: string;
}

export interface Lead {
  offer_id: string;
  points: string;
}

export type Platform = 'ios' | 'android';
